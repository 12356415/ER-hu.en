package com.emon.erhuman

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.util.Log

class ERAccessibilityService : AccessibilityService() {
    companion object {
        var instance: ERAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // এখানে দৃশ্যমান UI-এর নিরাপদ, ব্যবহারকারীর অনুমোদিত পর্যবেক্ষণ করা যায়।
        // ভবিষ্যৎ planner এখান থেকে visible text/node tree ব্যবহার করবে।
    }

    fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x,y) }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path,0,80)).build(), null, null)
    }

    fun swipe(x1:Float,y1:Float,x2:Float,y2:Float,duration:Long=350) {
        val path=Path().apply { moveTo(x1,y1); lineTo(x2,y2) }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path,0,duration)).build(), null, null)
    }

    fun writeText(node: AccessibilityNodeInfo, text: String) {
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    override fun onInterrupt() {}
    override fun onDestroy() { instance=null; super.onDestroy() }
}