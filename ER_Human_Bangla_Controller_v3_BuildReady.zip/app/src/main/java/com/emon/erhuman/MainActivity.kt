package com.emon.erhuman

import android.app.Activity
import android.os.Bundle
import android.provider.Settings
import android.content.Intent
import android.net.Uri
import android.widget.*
import android.view.WindowManager

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.access).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.overlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, OverlayService::class.java))
            }
        }
        findViewById<Button>(R.id.start).setOnClickListener {
            startService(Intent(this, OverlayService::class.java))
            findViewById<TextView>(R.id.status).text = "ER চালু আছে • স্ক্রিনে দেখা যাবে"
        }
    }
}