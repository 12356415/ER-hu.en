package com.emon.erhuman

import android.app.*
import android.content.*
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var view: View? = null

    override fun onCreate() {
        super.onCreate()
        val channelId = "er_assistant"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channelId, "ER সহকারী", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, channelId)
            .setContentTitle("ER চালু আছে")
            .setContentText("স্ক্রিনের উপর ER দৃশ্যমান")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        startForeground(1001, n)
        showHuman()
    }

    private fun showHuman() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14,10,14,10)
            val bg = GradientDrawable()
            bg.setColor(Color.argb(225, 10,15,22))
            bg.cornerRadius = 40f
            background = bg
        }
        val human = TextView(this).apply {
            text = "◉\n╱│╲\n ╱ ╲"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        val status = TextView(this).apply {
            text = "ER • প্রস্তুত"
            textSize = 11f
            setTextColor(Color.rgb(32,213,138))
            gravity = Gravity.CENTER
        }
        box.addView(human, LinearLayout.LayoutParams(75,85))
        box.addView(status, LinearLayout.LayoutParams(75,30))

        val p = WindowManager.LayoutParams(
            100, 125,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.END
        p.x = 18; p.y = 90
        box.setOnTouchListener(DragTouchListener(wm, p))
        view = box
        wm.addView(box,p)
    }

    override fun onDestroy() {
        view?.let { wm.removeView(it) }
        super.onDestroy()
    }
    override fun onBind(intent: Intent?) = null
}

class DragTouchListener(private val wm: WindowManager, private val p: WindowManager.LayoutParams): View.OnTouchListener {
    private var sx=0f; private var sy=0f; private var ox=0; private var oy=0
    override fun onTouch(v: View, e: MotionEvent): Boolean {
        when(e.action) {
            MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; return true }
            MotionEvent.ACTION_MOVE -> { p.x=ox-(e.rawX-sx).toInt(); p.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(v,p); return true }
        }
        return true
    }
}