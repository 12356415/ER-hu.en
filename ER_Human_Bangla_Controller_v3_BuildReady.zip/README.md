# ER Human Bangla Controller

এটি Android-এর জন্য একটি ভিত্তি প্রকল্প:
- বাংলায় ER UI
- স্ক্রিনের উপর ভাসমান মানব-চরিত্র
- Accessibility Service
- দৃশ্যমান tap/swipe করার ক্ষমতা
- Overlay + foreground service
- পরবর্তী ধাপে AI planner, Bengali voice recognition, wake word এবং app-specific workflows যোগ করার জন্য পরিষ্কার কাঠামো

গুরুত্বপূর্ণ:
1. Android Studio-তে খুলে Gradle sync/build করুন।
2. ফোনে Accessibility ও Display over other apps অনুমতি ব্যবহারকারীকে নিজে দিতে হবে।
3. এই প্রকল্প পাসওয়ার্ড, OTP, ব্যাংক/বিকাশ/নগদ পেমেন্ট বা CAPTCHA bypass করে না।
4. বাস্তব “মানুষের মতো” স্বাভাবিক ভাষা বোঝার জন্য একটি AI/LLM backend এবং voice layer সংযুক্ত করতে হবে; API key কোডে hard-code করবেন না।
5. Facebook/অন্যান্য অ্যাকাউন্টের ব্যক্তিগত ডেটা পড়ার ক্ষেত্রে অনুমোদিত official API/নিজের account authorization ব্যবহার করতে হবে।
