# ER Human Bangla Controller v3 — Build Ready

## ফোনে AndroidIDE দিয়ে
1. এই ZIP extract/import করো।
2. Project open করো।
3. Gradle sync শেষ হতে দাও।
4. Build > Assemble Debug চাপো।
5. APK: app/build/outputs/apk/debug/

## GitHub Actions দিয়ে cloud build
1. Project files একটি GitHub repository-তে upload করো।
2. `.github/workflows/build-apk.yml` আগে থেকেই আছে।
3. GitHub → Actions → Build ER APK → Run workflow।
4. Build শেষ হলে workflow-এর Artifacts থেকে `ER-debug-apk` download করো।

## Build settings
- Android Gradle Plugin: 8.7.3
- Kotlin: 2.0.21
- Gradle: 8.9
- JDK: 17
- Compile SDK: 35
- Min SDK: 26

## Important
Accessibility/overlay/microphone permissions অবশ্যই Android Settings থেকে user-কে দিতে হবে।
Password, OTP, banking/payment confirmation বা CAPTCHA bypass করার automation এই project-এ দেওয়া হয়নি।
